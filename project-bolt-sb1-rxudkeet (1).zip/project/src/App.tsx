import React from 'react';
import { Heart, ShoppingBag, Search, Menu, Instagram, Facebook, Apple as WhatsApp } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Menu className="h-6 w-6 md:hidden" />
              <h1 className="ml-4 text-2xl font-serif">Elegance</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-700 hover:text-gray-900">Coleções</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">Anéis</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">Brincos</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">Colares</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">Pulseiras</a>
            </nav>
            <div className="flex items-center space-x-4">
              <Search className="h-5 w-5" />
              <Heart className="h-5 w-5" />
              <ShoppingBag className="h-5 w-5" />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[600px]">
        <img 
          src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&q=80"
          alt="Jewelry Collection"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-5xl font-serif mb-4">Nova Coleção</h2>
            <p className="text-xl mb-8">Descubra nossa exclusiva linha de semijoias</p>
            <button className="bg-white text-black px-8 py-3 rounded-full hover:bg-gray-100 transition">
              Ver Coleção
            </button>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-serif text-center mb-12">Destaques</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&q=80",
                name: "Anel Dourado Cristal",
                price: "R$ 159,90"
              },
              {
                image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80",
                name: "Colar Pérolas",
                price: "R$ 189,90"
              },
              {
                image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80",
                name: "Brincos Cristal",
                price: "R$ 129,90"
              }
            ].map((product, index) => (
              <div key={index} className="group">
                <div className="relative overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-[400px] object-cover transition transform group-hover:scale-105"
                  />
                  <button className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white text-black px-6 py-2 rounded-full opacity-0 group-hover:opacity-100 transition">
                    Comprar
                  </button>
                </div>
                <div className="text-center mt-4">
                  <h3 className="text-lg font-medium">{product.name}</h3>
                  <p className="text-gray-600">{product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              {
                image: "https://images.unsplash.com/photo-1602751584552-8ba73aad10e1?auto=format&fit=crop&q=80",
                name: "Anéis"
              },
              {
                image: "https://images.unsplash.com/photo-1635767798638-3665960e9533?auto=format&fit=crop&q=80",
                name: "Colares"
              },
              {
                image: "https://images.unsplash.com/photo-1573408301185-9146fe634ad0?auto=format&fit=crop&q=80",
                name: "Brincos"
              },
              {
                image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80",
                name: "Pulseiras"
              }
            ].map((category, index) => (
              <div key={index} className="relative group cursor-pointer">
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-[200px] object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-30 transition flex items-center justify-center">
                  <h3 className="text-white text-xl font-medium">{category.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-lg font-serif mb-4">Sobre Nós</h4>
              <p className="text-gray-400">Elegance é uma marca de semijoias que combina elegância e qualidade para criar peças únicas.</p>
            </div>
            <div>
              <h4 className="text-lg font-serif mb-4">Atendimento</h4>
              <ul className="space-y-2 text-gray-400">
                <li>contato@elegance.com.br</li>
                <li>(11) 99999-9999</li>
                <li>Segunda a Sexta: 9h às 18h</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-serif mb-4">Links Úteis</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Política de Trocas</a></li>
                <li><a href="#" className="hover:text-white">Termos de Uso</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-serif mb-4">Redes Sociais</h4>
              <div className="flex space-x-4">
                <Instagram className="h-6 w-6" />
                <Facebook className="h-6 w-6" />
                <WhatsApp className="h-6 w-6" />
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Elegance. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;